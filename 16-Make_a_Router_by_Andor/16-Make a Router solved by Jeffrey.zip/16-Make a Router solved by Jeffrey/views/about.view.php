<?php require('partials/head.php'); ?>

    <h1>About Us</h1>

<?php require('partials/footer.php'); ?>
