<nav>
    <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/about">About</a></li>
        <li><a href="/about/culture">About Our Culture</a></li>
        <li><a href="/contact">Contact</a></li>
    </ul>
</nav>