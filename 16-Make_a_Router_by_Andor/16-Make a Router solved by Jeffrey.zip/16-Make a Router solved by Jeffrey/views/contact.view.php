<?php require('partials/head.php'); ?>

    <h1>Contact Us</h1>

<?php require('partials/footer.php'); ?>
