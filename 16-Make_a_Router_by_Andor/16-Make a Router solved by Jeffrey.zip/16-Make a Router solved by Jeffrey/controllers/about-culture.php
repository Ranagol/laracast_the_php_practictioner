<?php

$name = 'Laracasts';

require 'views/about-culture.view.php';